from setuptools import setup

setup(
    name='ft_package',
    version="69.0",
    summary='contains tools related to lists',
	url='https://github.com/Luxins',
	author_email='69@69.com',
    license='Gnu public lisence',
    location='/goinfre/ljahn/python0/ex09',
    requires=[],
)